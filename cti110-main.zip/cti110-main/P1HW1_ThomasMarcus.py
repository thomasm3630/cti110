integer = 4
anotherinteger = 5
print("Enter integer:")
print(integer)
print("You entered:",integer)
print(integer, "squared is 16")
print("And", integer, "cubed is 64 !!")
print("Enter another integer:")
print(anotherinteger)
print(integer, "+", anotherinteger,"is 9")
print(integer, "*", anotherinteger,"is 20")
