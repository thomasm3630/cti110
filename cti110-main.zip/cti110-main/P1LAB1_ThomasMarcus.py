#Marcus Thomas
#04/14/2024
#P1Lab1
#Input and print

print('Enter your first name:')

firstname = input('Enter your first name:')

print('Enter your last name:')

lastname = input('Enter your last name:')

print("Hello", firstname , lastname,  " ! Welcome to CTI-110")

