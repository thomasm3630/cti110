#Marcus Thomas
#05/01/2024
#P4HW2
#Loops


Score = float(input("How many scores do you want to enter"))
average_gde.append(Score)
for item in range []:
    scores = input("How many scores do you want to enter")
print()
print()
print("------------Results------------")







for item in range [] :
    scores = input("How many scores do you want to enter")
print()


while score < 0.0 or num > 100.0:
    print("Invalid Score Entered!!!")
    print("Score should be entered 0 to 100")
    num = float(input("Try again "))

    
